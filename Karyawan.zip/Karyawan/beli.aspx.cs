﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Karyawan_beli : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Default"].ConnectionString);
    DataSet ds = new DataSet();
    private const string Ascending = " ASC";
    private const string Descending = " DESC";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            string mainconn = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(mainconn);
            string sqlquery = "select IDObat,namaObat,IDJenis,JumlahObat,Satuan,Keterangan from obat";
            SqlCommand com = new SqlCommand(sqlquery, sqlconn);
            sqlconn.Open();
            gridObat.DataSource = com.ExecuteReader();
            gridObat.DataBind();
            sqlconn.Close();

        }
    }

    protected void Keranjang_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridObat.PageIndex = e.NewPageIndex;
        gridObat.DataBind();
    }

    protected void Keranjang_SelectedIndexChanged(object sender, EventArgs e)
    {

       
    }

    protected void Keranjang_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }

    protected void Keranjang_Sorting(object sender, GridViewSortEventArgs e)
    {

    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }



    protected void gridObat_Sorting(object sender, GridViewSortEventArgs e)
    {

    }

    protected void btnSearch_Click1(object sender, EventArgs e)
    {

    }




    protected void gridObat_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }

    protected void gridObat_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void gridObat_Sorting1(object sender, GridViewSortEventArgs e)
    {

    }

    protected void gridObat_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }

    protected void gridObat_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void gridObat_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }



    protected void rbResep_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }


    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }

    protected void btnKeranjang_Click(object sender, EventArgs e)
    {
        

    }

    protected void keranjang_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("namaObat");
        dt.Columns.Add("Satuan");
       // dt.Columns.Add("jumlah");
       
        foreach (GridViewRow grow in gridObat.Rows)
        {
            var checkboxselect = grow.FindControl("CheckBox1") as CheckBox;
            if (checkboxselect.Checked)
            {
                string Name = (grow.FindControl("labNama") as Label).Text;
                string satuan = (grow.FindControl("labSat") as Label).Text; 
                //string jumlah = (grow.FindControl("labJumlah") as TextBox).Text;
               
                dt.Rows.Add(Name,satuan);
            }

            grdKeranjang.DataSource = dt;
            grdKeranjang.DataBind();
           

        }
        Response.Write("<script>alert('Data berhasil dimasukkan kekeranjang');</script>");
    }

    protected void jumlahBeli_TextChanged(object sender, EventArgs e)
    {

    }
}